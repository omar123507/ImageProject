# 🖼️ Image Processing API

FastAPI backend built from the `Total.ipynb` notebook.  
All endpoints accept and return **Base64-encoded images** (PNG by default).

---

## 🚀 Quick Start

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Then open **http://localhost:8000/docs** for the interactive Swagger UI.

---

## 📡 API Endpoints

### 1. Point Operations — `/api/point-ops`

| Method | Endpoint | Body | Description |
|--------|----------|------|-------------|
| POST | `/add` | `image`, `value` | Add constant to all pixels |
| POST | `/subtract` | `image`, `value` | Subtract constant from all pixels |
| POST | `/divide` | `image`, `value` | Divide all pixels by constant |
| POST | `/complement` | `image` | Invert image (255 - pixel) |

---

### 2. Color Manipulation — `/api/color`

| Method | Endpoint | Body | Description |
|--------|----------|------|-------------|
| POST | `/red` | `image`, `value` | Adjust Red channel |
| POST | `/green` | `image`, `value` | Adjust Green channel |
| POST | `/blue` | `image`, `value` | Adjust Blue channel |
| POST | `/swap/red-green` | `image` | Swap Red & Green channels |
| POST | `/swap/red-blue` | `image` | Swap Red & Blue channels |
| POST | `/swap/green-blue` | `image` | Swap Green & Blue channels |
| POST | `/eliminate/red` | `image` | Set Red channel to 0 |
| POST | `/eliminate/green` | `image` | Set Green channel to 0 |
| POST | `/eliminate/blue` | `image` | Set Blue channel to 0 |

---

### 3. Histogram — `/api/histogram`

| Method | Endpoint | Body | Description |
|--------|----------|------|-------------|
| POST | `/stretch` | `image` | Histogram stretching |
| POST | `/equalize` | `image` | Histogram equalization |
| POST | `/values` | `image` | Get histogram data (B, G, R, Gray) |

---

### 4. Filters — `/api/filters`

| Method | Endpoint | Body | Description |
|--------|----------|------|-------------|
| POST | `/average` | `image` | 3×3 Average filter |
| POST | `/laplacian` | `image` | 3×3 Laplacian (edge sharpening) |
| POST | `/maximum` | `image` | 3×3 Maximum filter (dilation) |
| POST | `/minimum` | `image` | 3×3 Minimum filter (erosion) |
| POST | `/median` | `image` | 3×3 Median filter |
| POST | `/mode` | `image` | 3×3 Mode filter |

---

### 5. Image Restoration — `/api/restoration`

| Method | Endpoint | Body | Description |
|--------|----------|------|-------------|
| POST | `/noise/salt-pepper` | `image`, `prob` | Add salt-and-pepper noise |
| POST | `/noise/gaussian` | `image`, `mean`, `std` | Add Gaussian noise |
| POST | `/filter/average` | `image` | Average filter on grayscale |
| POST | `/filter/median` | `image` | Median filter on grayscale |
| POST | `/filter/outlier` | `image`, `threshold` | Outlier filter |
| POST | `/filter/averaging` | `image1`, `image2` | Average two images |

---

### 6. Segmentation — `/api/segmentation`

| Method | Endpoint | Body | Description |
|--------|----------|------|-------------|
| POST | `/basic-global` | `image`, `thresh_value` | Basic global thresholding |
| POST | `/otsu` | `image`, `thresh_value` | Otsu's automatic thresholding |
| POST | `/adaptive` | `image` | Adaptive mean thresholding |
| POST | `/vertical-otsu` | `image` | Vertical segments Otsu |

---

### 7. Edge Detection — `/api/edge-detection`

| Method | Endpoint | Body | Description |
|--------|----------|------|-------------|
| POST | `/sobel` | `image` | Sobel edge detection → returns `combined`, `grad_x`, `grad_y`, `grad_avg` |

---

### 8. Morphology — `/api/morphology`

| Method | Endpoint | Body | Description |
|--------|----------|------|-------------|
| POST | `/dilation` | `image`, `kernel_size` | Morphological dilation |
| POST | `/erosion` | `image`, `kernel_size` | Morphological erosion |
| POST | `/opening` | `image`, `kernel_size` | Morphological opening |
| POST | `/boundary/internal` | `image`, `kernel_size` | Internal boundary |
| POST | `/boundary/external` | `image`, `kernel_size` | External boundary |
| POST | `/gradient` | `image`, `kernel_size` | Morphological gradient |

---

## 🌐 How to Call from Your Frontend (JavaScript)

```javascript
async function processImage(imageFile, endpoint, params = {}) {
  // 1. Convert file to base64
  const base64 = await fileToBase64(imageFile);

  // 2. Build request body
  const body = { image: base64, ...params };

  // 3. Call the API
  const res = await fetch(`http://localhost:8000${endpoint}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  const data = await res.json();

  // 4. Display the result image
  return `data:image/png;base64,${data.image}`;
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(",")[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// ── Usage examples ─────────────────────────────────────────────────────────

// Point Operations
const negImg = await processImage(file, "/api/point-ops/complement");
const brightImg = await processImage(file, "/api/point-ops/add", { value: 50 });

// Filters
const blurImg = await processImage(file, "/api/filters/average");
const edgeImg = await processImage(file, "/api/filters/laplacian");

// Segmentation
const otsuImg = await processImage(file, "/api/segmentation/otsu", { thresh_value: 127 });

// Morphology (with kernel size)
const dilImg = await processImage(file, "/api/morphology/dilation", { kernel_size: 5 });

// Sobel — multiple outputs
const res = await fetch("http://localhost:8000/api/edge-detection/sobel", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ image: base64Image }),
});
const { combined, grad_x, grad_y, grad_avg } = await res.json();
// each is a base64 string → prefix with "data:image/png;base64,"
```

---

## 📦 Response Format

Most endpoints return:
```json
{
  "image": "<base64 string>",
  "format": "png",
  "width": 640,
  "height": 480
}
```

`/api/edge-detection/sobel` returns:
```json
{
  "combined": "<base64>",
  "grad_x":   "<base64>",
  "grad_y":   "<base64>",
  "grad_avg": "<base64>",
  "width": 640,
  "height": 480
}
```

`/api/histogram/values` returns:
```json
{
  "blue":  [0, 12, 34, ...],
  "green": [0, 8, 21, ...],
  "red":   [0, 5, 19, ...],
  "gray":  [0, 10, 28, ...]
}
```
